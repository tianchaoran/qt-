﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "waypoint.h"
#include "enemy.h"
#include "bullet.h"
#include "audioplayer.h"
#include "plistreader.h"
#include <QPainter>
#include <QMouseEvent>
#include <QtGlobal>
#include <QMessageBox>
#include <QTimer>
#include <QXmlStreamReader>
#include <QtDebug>

Dailog::Dailog(QWidget *parent)
     : QWidget(parent)
{
    ui->setupUi(this);
}

Dailog::~Dailog(){
        delete ui;
}
