﻿#ifndef TOWER1_H
#define TOWER1_H


class tower1
{
public:
    tower1();
};

#endif // TOWER1_H